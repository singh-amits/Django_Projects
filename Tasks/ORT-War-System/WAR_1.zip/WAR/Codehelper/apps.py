from django.apps import AppConfig


class CodehelperConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Codehelper'
